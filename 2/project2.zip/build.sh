set -e

g++ -Wall angryBricks.cpp -o p -lGL -lGLU -lglut

./p
